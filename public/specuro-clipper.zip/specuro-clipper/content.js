

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "getPageData") {
    // 1. 抓图 (保持原样)
    let img = document.querySelector('meta[property="og:image"]')?.content;
    if (!img) {
      const allImgs = Array.from(document.getElementsByTagName('img'))
        .filter(i => i.width > 200)
        .sort((a, b) => b.width * b.height - a.width * a.height);
      img = allImgs[0]?.src || "";
    }

    // 2. 抓文 (保持原样)
    const text = document.body.innerText.replace(/\s+/g, ' ').substring(0, 3000);

    // 3. 增强版 PDF 识别 (寻找包含 spec, tear, assembly, manual 等字眼的 PDF 链接)
    const pdfKeywords = /spec|tear|dimen|assembly|manual|guide|document/i;
    const allLinks = Array.from(document.querySelectorAll('a[href$=".pdf"]'));
    const pdfLink = allLinks.find(a => pdfKeywords.test(a.innerText) || pdfKeywords.test(a.href))?.href || "";

    sendResponse({ image: img, text: text, pdf: pdfLink });
  }
  return true;
});