chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "getPageData") {
    
    // --- 1. 图片抓取优先级逻辑 ---
    let imageUrl = "";

    // 优先级 A: 知名电商平台的主图专用 ID (Amazon, IKEA, Wayfair)
    const primarySelectors = [
      '#landingImage',        // Amazon 标配
      '#main-image',          // Amazon 备选
      '#imgBlkFront',         // Amazon 书籍/特殊品
      '.pip-image',           // IKEA 标配
      '.product-image-main',  // 通用
      'meta[property="og:image"]' // 社交分享图
    ];

    for (let selector of primarySelectors) {
      const el = selector.startsWith('meta') 
        ? document.querySelector(selector) 
        : document.querySelector(selector);
      
      if (el) {
        imageUrl = el.getAttribute('content') || el.src;
        if (imageUrl) break;
      }
    }

    // 优先级 B: 如果没找到专用 ID，寻找页面上半部分面积最大的图
    if (!imageUrl) {
      const allImgs = Array.from(document.getElementsByTagName('img'))
        .filter(i => {
          const rect = i.getBoundingClientRect();
          // 过滤掉太小的图和页面下方的图（描述区通常在下方）
          return i.width > 250 && rect.top < 1500; 
        })
        .sort((a, b) => (b.width * b.height) - (a.width * a.height));
      
      imageUrl = allImgs[0]?.src || "";
    }

    // --- 2. 文本抓取 (保持原样) ---
    const text = document.body.innerText.replace(/\s+/g, ' ').substring(0, 3500);

    // --- 3. PDF 抓取 (保持原样) ---
    const pdfKeywords = /spec|tear|dimen|assembly|manual|guide|document/i;
    const allLinks = Array.from(document.querySelectorAll('a[href$=".pdf"]'));
    const pdfLink = allLinks.find(a => pdfKeywords.test(a.innerText) || pdfKeywords.test(a.href))?.href || "";

    sendResponse({ 
      image: imageUrl, 
      text: text, 
      pdf: pdfLink 
    });
  }
  return true;
});