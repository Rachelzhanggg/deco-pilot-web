const CONFIG = {
    DEEPSEEK_API_KEY: "sk-a1402c10818b45c4b547e9028a177165",
    SUPABASE_URL: "https://kxwdlhgwjfzhtvxqanwx.supabase.co",
    SUPABASE_ANON_KEY: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt4d2RsaGd3amZ6aHR2eHFhbnd4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzg0MDM1MzIsImV4cCI6MjA5Mzk3OTUzMn0.l7dTWEG06HYASy-nD5hK3hQu1BgWNqkTxy9r7fl3yQU"
};

let currentData = {};

document.addEventListener('DOMContentLoaded', () => {
  const extractBtn = document.getElementById('extractBtn');
  const saveBtn = document.getElementById('saveBtn');
  const status = document.getElementById('status');
  const resultDiv = document.getElementById('result');

  // --- 1. 捕获与 AI 分析逻辑 ---
  extractBtn.addEventListener('click', async () => {
    extractBtn.disabled = true;
    status.style.display = 'block';
    status.innerText = "CONNECTING TO AI...";
    resultDiv.style.display = 'none';

    // 获取当前标签页
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    // 向 Content Script 请求网页原始数据
    chrome.tabs.sendMessage(tab.id, { action: "getPageData" }, async (response) => {
      if (chrome.runtime.lastError || !response) {
        alert("ERROR: PLEASE REFRESH THE FURNITURE PAGE.");
        resetUI();
        return;
      }

      currentData = {
        image_url: response.image,
        source_url: tab.url,
        pdf_url: response.pdf
      };


      // ... CONFIG 保持不变 ...

// 更新 Prompt 确保 AI 返回 Category 和 Style
const prompt = `You are a professional Interior Design Sourcing Agent. 
Analyze the text and extract furniture specifications into a JSON object.
Keys: "name", "price", "color", "dimensions", "lead_time", "type", "style".

CRITICAL INSTRUCTIONS:
1. "type": Must be one of [SEATING, TABLES, LIGHTS, STORAGE, ACCESSORIES].
2. "style": Must be one of [MODERN, MINIMAL, INDUSTRIAL, TRANSITIONAL].
3. PRICE: Always include currency (e.g. $599).
Text: ${response.text.substring(0, 3000)}`;

      try {
        const res = await fetch("https://api.deepseek.com/chat/completions", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${CONFIG.DEEPSEEK_API_KEY}`
          },
          body: JSON.stringify({
            model: "deepseek-chat",
            messages: [{ role: "user", content: prompt }],
            response_format: { type: "json_object" }
          })
        });

        if (!res.ok) throw new Error("AI_LIMIT_REACHED_OR_KEY_INVALID");

        const aiRes = await res.json();
        const data = JSON.parse(aiRes.choices[0].message.content);

        // 填充 UI 供用户微调
        document.getElementById('name_i').value = data.name || "";
        document.getElementById('price_i').value = data.price || "";
        document.getElementById('color_i').value = data.color || "";
        document.getElementById('dims_i').value = data.dimensions || "";
        document.getElementById('lead_i').value = data.lead_time || "";

        // 处理 PDF 显示
        if (currentData.pdf_url) {
          document.getElementById('pdf_container').style.display = 'block';
          document.getElementById('pdf_link').href = currentData.pdf_url;
        }

        status.style.display = 'none';
        resultDiv.style.display = 'block';
        extractBtn.innerText = "RE-CAPTURE";
        extractBtn.disabled = false;

      } catch (e) {
        alert("ANALYSIS FAILED: " + e.message);
        resetUI();
      }
    });
  });

  // --- 2. 保存到 Supabase 逻辑 (含多用户隔离) ---
  saveBtn.addEventListener('click', async () => {
    // 检查本地是否有用户 Token
    chrome.storage.local.get(['specuro_user_id'], async (result) => {
      let userId = result.specuro_user_id;

      // 如果没有 Token，提示用户输入（用户从网站后台获取自己的 UUID）
      if (!userId) {
        userId = prompt("PLEASE ENTER YOUR PERSONAL ACCESS TOKEN (Found in SPECURO Dashboard Settings):");
        if (userId) {
          chrome.storage.local.set({ specuro_user_id: userId });
        } else {
          return; // 用户取消
        }
      }

      saveBtn.innerText = "SAVING...";
      saveBtn.disabled = true;

      // 在保存逻辑中加入这两个字段
const payload = {
    user_id: userId,
    name: document.getElementById('name_i').value,
    price: document.getElementById('price_i').value,
    color: document.getElementById('color_i').value,
    dimensions: document.getElementById('dims_i').value,
    lead_time: document.getElementById('lead_i').value,
    type: document.getElementById('type_i').value.toUpperCase(), // 新增
    style: document.getElementById('style_i').value.toUpperCase(), // 新增
    image_url: currentData.image_url,
    source_url: currentData.source_url,
    pdf_url: currentData.pdf_url
};

      try {
        const res = await fetch(`${CONFIG.SUPABASE_URL}/rest/v1/furniture`, {
          method: "POST",
          headers: {
            "apikey": CONFIG.SUPABASE_ANON_KEY,
            "Authorization": `Bearer ${CONFIG.SUPABASE_ANON_KEY}`,
            "Content-Type": "application/json"
          },
          body: JSON.stringify(payload)
        });

        if (res.ok) {
          saveBtn.innerText = "SUCCESS ✓";
          setTimeout(() => window.close(), 1000);
        } else {
          const errData = await res.json();
          console.error(errData);
          // 如果报错 42501，说明 Supabase 的 RLS 策略拒绝了写入（未授权）
          alert("SYNC ERROR: PLEASE CHECK YOUR ACCESS TOKEN.");
          saveBtn.disabled = false;
          saveBtn.innerText = "SAVE TO ARCHIVE";
        }
      } catch (e) {
        alert("NETWORK ERROR");
        saveBtn.disabled = false;
      }
    });
  });

  function resetUI() {
    extractBtn.disabled = false;
    extractBtn.innerText = "CAPTURE SPEC";
    status.style.display = 'none';
  }
});