const CONFIG = {
    DEEPSEEK_API_KEY: "sk-a1402c10818b45c4b547e9028a177165",
    SUPABASE_URL: "https://kxwdlhgwjfzhtvxqanwx.supabase.co",
    SUPABASE_ANON_KEY: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt4d2RsaGd3amZ6aHR2eHFhbnd4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzg0MDM1MzIsImV4cCI6MjA5Mzk3OTUzMn0.l7dTWEG06HYASy-nD5hK3hQu1BgWNqkTxy9r7fl3yQU"
};

let currentData = {};

document.addEventListener('DOMContentLoaded', () => {
  const extractBtn = document.getElementById('extractBtn');
  const saveBtn = document.getElementById('saveBtn');
  const status = document.getElementById('status');
  const resultDiv = document.getElementById('result');

  // --- 第一步：点击 Capture 调用 AI 分析网页 ---
  extractBtn.addEventListener('click', async () => {
    // UI 状态切换
    extractBtn.disabled = true;
    extractBtn.innerText = "ANALYZING...";
    status.style.display = 'block';
    status.innerText = "READING DATA FROM PAGE...";
    resultDiv.style.display = 'none';

    // 获取当前活动的标签页
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    // 向 content.js 发送请求获取网页文本和图片
    chrome.tabs.sendMessage(tab.id, { action: "getPageData" }, async (response) => {
      if (chrome.runtime.lastError || !response) {
        alert("ERROR: PLEASE REFRESH THE FURNITURE PAGE.");
        resetUI();
        return;
      }

      status.innerText = "AI IDENTIFYING SPECS...";

      // 暂存抓取到的图片和来源网址
      currentData = {
        image_url: response.image,
        source_url: tab.url,
        pdf_url: response.pdf
      };

      // 构造 AI 提示词（针对美国/中东市场优化）
      const prompt = `You are a professional Interior Design Sourcing Agent. 
      Analyze the text and extract furniture specifications into a JSON object.
      
      KEYS TO EXTRACT: 
      "name", "price", "color", "dimensions", "lead_time", "type", "style".

      CRITICAL RULES:
      1. "type": Categorize as ONE of: [SEATING, TABLES, LIGHTS, STORAGE, ACCESSORIES].
      2. "style": Categorize as ONE of: [MODERN, MINIMAL, INDUSTRIAL, TRANSITIONAL].
      3. "price": Include currency (e.g. $1,200 or 4,500 AED). Infer from URL: ${tab.url}.
      4. "dimensions": Provide BOTH Inches and CM if available.
      5. "name": Brand name + Product name.

      Text to analyze: ${response.text.substring(0, 3500)}`;

      try {
        const res = await fetch("https://api.deepseek.com/chat/completions", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${CONFIG.DEEPSEEK_API_KEY}`
          },
          body: JSON.stringify({
            model: "deepseek-chat",
            messages: [{ role: "user", content: prompt }],
            response_format: { type: "json_object" }
          })
        });

        if (!res.ok) throw new Error("AI_OFFLINE_OR_LIMIT_REACHED");

        const aiRes = await res.json();
        const data = JSON.parse(aiRes.choices[0].message.content);

        // 将 AI 结果填充到表单，允许设计师手动微调
        document.getElementById('name_i').value = data.name || "";
        document.getElementById('price_i').value = data.price || "";
        document.getElementById('color_i').value = data.color || "";
        document.getElementById('dims_i').value = data.dimensions || "";
        document.getElementById('lead_i').value = data.lead_time || "";
        
        // 分类和风格强制转大写，以匹配网页端筛选器
        document.getElementById('type_i').value = (data.type || "SEATING").toUpperCase();
        document.getElementById('style_i').value = (data.style || "MODERN").toUpperCase();

        // 如果找到了 PDF，显示下载预览链接
        if (currentData.pdf_url) {
          document.getElementById('pdf_container').style.display = 'block';
          document.getElementById('pdf_link').href = currentData.pdf_url;
        } else {
          document.getElementById('pdf_container').style.display = 'none';
        }

        // 显示结果面板
        status.style.display = 'none';
        resultDiv.style.display = 'block';
        extractBtn.innerText = "RE-CAPTURE";
        extractBtn.disabled = false;

      } catch (e) {
        alert("ANALYSIS FAILED: " + e.message);
        resetUI();
      }
    });
  });

saveBtn.addEventListener('click', async () => {
  console.log("Save button clicked"); // 调试日志

  // 1. 检查存储权限并获取 Token
  chrome.storage.local.get(['specuro_user_id'], async (result) => {
    let userId = result.specuro_user_id;

    // 2. 如果没有 Token，弹出输入框
    if (!userId) {
      userId = window.prompt("PLEASE ENTER YOUR PERSONAL TOKEN (Found in SPECURO Header):");
      if (userId && userId.length > 5) {
        chrome.storage.local.set({ specuro_user_id: userId }, () => {
          alert("TOKEN SAVED. CLICK SAVE AGAIN TO SYNC.");
        });
        return; // 保存完让用户再点一次保存
      } else {
        alert("TOKEN IS REQUIRED TO SAVE.");
        return;
      }
    }

    // 3. 开始保存流程
    saveBtn.innerText = "SAVING...";
    saveBtn.disabled = true;

    // 获取当前编辑框的值
    const payload = {
      user_id: userId,
      name: document.getElementById('name_i').value,
      price: document.getElementById('price_i').value,
      type: document.getElementById('type_i').value.toUpperCase(),
      style: document.getElementById('style_i').value.toUpperCase(),
      color: document.getElementById('color_i').value,
      dimensions: document.getElementById('dims_i').value,
      lead_time: document.getElementById('lead_i').value,
      image_url: currentData.image_url,
      source_url: currentData.source_url,
      pdf_url: currentData.pdf_url
    };

    try {
      const res = await fetch(`${CONFIG.SUPABASE_URL}/rest/v1/furniture`, {
        method: "POST",
        headers: {
          "apikey": CONFIG.SUPABASE_ANON_KEY,
          "Authorization": `Bearer ${CONFIG.SUPABASE_ANON_KEY}`,
          "Content-Type": "application/json",
          "Prefer": "return=minimal"
        },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        saveBtn.innerText = "SUCCESS ✓";
        setTimeout(() => window.close(), 1000);
      } else {
        const errorText = await res.text();
        console.error("Supabase Error:", errorText);
        alert("SYNC ERROR: " + errorText);
        saveBtn.disabled = false;
        saveBtn.innerText = "SAVE TO ARCHIVE";
      }
    } catch (e) {
      alert("CONNECTION FAILED: CHECK YOUR VPN.");
      saveBtn.disabled = false;
      saveBtn.innerText = "SAVE TO ARCHIVE";
    }
  });
});

  // UI 重置函数
  function resetUI() {
    extractBtn.disabled = false;
    extractBtn.innerText = "CAPTURE SPEC";
    status.style.display = 'none';
  }
});